const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/users.js'); // Adjust the path as per your project structure
require('dotenv').config();



// Route for user registration (sign-up)
router.post('/register', async (req, res) => {
    const { UserName, Email, Password, PhoneNo, role } = req.body;

    try {
        // Check if user already exists
        let user = await User.findOne({ Email });
        if (user) {
            return res.status(400).json({ msg: 'User already exists' });
        }

        // Create new user
        user = new User({ UserName, Email, Password, PhoneNo, role });

        // Hash password
        const salt = await bcrypt.genSalt(10);
        user.Password = await bcrypt.hash(Password, salt);

        // Save user to database
        await user.save();

        // Return success response
        res.status(201).json({ msg: 'User registered successfully' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// Route for user login
router.post('/login', async (req, res) => {
    const { Email, Password } = req.body;

    try {
        // Check if user exists
        let user = await User.findOne({ Email });
        if (!user) {
            return res.status(400).json({ msg: 'Invalid credentials' });
        }

        // Check if password is correct
        const isMatch = await bcrypt.compare(Password, user.Password);
        if (!isMatch) {
            return res.status(400).json({ msg: 'Invalid credentials' });
        }

        // Create payload for JWT
        const payload = {
            user: {
                id: user.id,
                role: user.role
            }
        };

        // Sign the JWT token
        jwt.sign(
            payload,
            process.env.JWT_SECRET,
            { expiresIn: '1h' },
            (err, token) => {
                if (err) throw err;
                res.json({ token });
            }
        );
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;
