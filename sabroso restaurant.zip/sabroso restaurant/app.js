const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const usersRoute = require('./routes/usersRoute.js');
const reservationsRoute = require('./routes/reservationsRoute.js');
const menuRoute = require('./routes/menuRoute.js');
const authRoute = require('./routes/authRoute.js');
require('dotenv').config();



const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.json());

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Define a route that renders the EJS template
app.get('/', (req, res) => {
  res.render('index', { name: 'World' });
});



app.use('/users', usersRoute);
app.use('/reservations', reservationsRoute);
app.use('/menu', menuRoute);
app.use('/api/auth', authRoute);



// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI).then(() => {
    console.log("Connected to database");
    app.listen(PORT, () => {
      console.log(`Server is running at http://localhost:${PORT}`);
    });
  })
  .catch(error => {
    console.error("Connection failed", error.message);
  });
