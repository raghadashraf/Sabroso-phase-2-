const mongoose = require('mongoose');
const UserSchema=mongoose.Schema(
    {
        UserName: {
            type:String,
            required:[true]
        },
        Email:{
            type:String,
            required:[true]
        },
        Password: {
            type:Number,
            required:[true]
        },
        PhoneNo:{
            type:Number,
            required:[true]
        },
        role: {
            type: String,
            enum: ['customer', 'admin'],
            default: 'customer',
            required:[true]
        },
        createdAt: {
            type: Date,
            default: Date.now 
        }
    }, { timestamps: true }
);
const User = mongoose.model("User",UserSchema);
module.exports=User;