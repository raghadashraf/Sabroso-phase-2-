const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const usersRoute = require('./routes/usersRoute.js');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.json());

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Define a route that renders the EJS template
app.get('/', (req, res) => {
  res.render('index', { name: 'World' });
});

app.use('/users', usersRoute);

// Connect to MongoDB
mongoose.connect("mongodb+srv://farah:PpNf0IqdEiMkwXgt@cluster0.6kmekap.mongodb.net/Node?retryWrites=true&w=majority&appName=Cluster0")
  .then(() => {
    console.log("Connected to database");
    app.listen(port, () => {
      console.log(`Server is running at http://localhost:${port}`);
    });
  })
  .catch(error => {
    console.error("Connection failed", error.message);
  });
