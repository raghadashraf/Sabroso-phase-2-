const mongoose = require('mongoose');
const UserSchema=mongoose.Schema(
    {
        UserName: {
            type:String,
            required:[true,"please enter your username"]
        },
        Email:{
            type:String,
            required:[true,"please enter your username"]
        },
        Password: {
            type:Number,
            required:[true," please enter your password"]
        },
        PhoneNo:{
            type:Number,
            required:[true,"please enter your username"]
        },
    }, { timestamps: true }
);
const User = mongoose.model("User",UserSchema);
module.exports=User;