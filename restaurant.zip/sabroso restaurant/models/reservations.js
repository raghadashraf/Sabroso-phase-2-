const mongoose = require('mongoose');
const ReservationsSchema=mongoose.Schema(
    {
        
    }, { timestamps: true }
);
const Reservations = mongoose.model("Reservations",ReservationsSchema);
module.exports=Reservations;